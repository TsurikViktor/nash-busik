<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$meta_1 = "Firma «NashBusik» realizuje codzienne przejazdy do Polski wygodnymi mikrobusami klasy Volkswagen Crafter, Mercedes Sprinter";
$meta_2 = "Przewozy pasażerskie Ukraina - Polska. NashBusik";
$meta_3 = "Firma «NashBusik» realizuje codzienne przewozy do Polski wygodnymi mikrobusami klasy Volkswagen Crafter, Mercedes Sprinter";
$meta_4 = "PRZEWOZY PASAŻERSKIE KRYVYI RIH - POLSKA";
$meta_5 = "Przewozy pasażerskie Ukraina - Polska. NashBusik";

$krgdynya = ""; //"1900 грн.";
$krgdansk = ""; //"1800 грн."
$krstarogradgdanskyy = ""; //"1800 грн.";
$krtchev = ""; //"1800 грн.";
$krkvidzyn = ""; //"1800 грн.";
$krgrudzens = ""; //"1800 грн.";
$krbydgosch = ""; //"1800 грн.";
$krposnan = ""; //"1600 грн.";
$krsvazhends = ""; //"1600 грн.";
$krvzhesnya = ""; //"1600 грн.";
$krkonin = ""; //"1600 грн.";
$krlodz = ""; //"1500 грн.";
$krglovno = ""; //"1500 грн.";
$krvarshava = ""; //"1300 грн.";
$krvrotslav = ""; //"1700 грн.";
$krturek = ""; //"1600 грн.";
$krtorun = ""; //"1800 грн.";

$menu_1 = "Trasy";
$menu_2 = "O nas";
$menu_3 = "Nasz transport";
$menu_4 = "Kontakty";
$requestACall = "Zadzwoń";
$langSelectPopup = "Strona internetowe w kilku językach: Українська, Русский";
$curLang = "Język";

$heading_1 = "Przewozy pasażerskie<br>Ukraina Polska";
$heading_2 = "«NashBusik» - międzynarodowy przewozy pasażerskie wygodnymi mikrobusami";
$heading_3 = "Rezerwacja online";

$route_1 = "Najpopularniejsze kierunki";
$route_2 = "Rejsy do Polski";
$route_3 = "Rejsy po Ukrainie";
$route_4 = "Codziennie";
$route_5 = "Kup";
$route_6 = "Dowiedz się więcej";

$about_1 = "Trochę o komforcie, który czeka na Ciebie podczas podróży";
$about_2 = "Firma «NashBusik» jest oficjalnym przewoźnikiem<br>i wykonuje codzienne przejazdy do Polski i Ukrainy na osobistych<br>wygodnych mikrobusach klasy<br>«Volkswagen Crafter, Mercedes Sprinter»";
$about_3 = "Profesjonalizm";
$about_4 = "«NashBusik» ma tylko profesjonalnych i uprzejmych kierowców.";
$about_5 = "Komfort";
$about_6 = "Wygodne mikrobusy z klimatyzacją, autonomicznym ogrzewaczem Webasto, ładowarkami USB.";
$about_7 = "Ceny";
$about_8 = "Najlepsze ceny na transport z Ukrainy do Polski i z powrotem.";
$about_9 = "Niezawodność";
$about_10 = "Jesteśmy rzetelną firmą, która odpowiedzialnie podchodzi do swoich zobowiązań, bo zależy nam, abyście zostali naszymi stałymi klientami.";
$about_11 = "Nasze przewagi:";
$about_12 = "Telewizor";
$about_13 = "Gniazdo USB";
$about_14 = "Ogrzewanie<br>wnętrza";
$about_15 = "Klimatyzacja";
$about_16 = "Darmowy<br>wi-fi";
$about_17 = "Wygodne<br>siedzenia";
$about_18 = "Szybka<br>odprawa<br>celna";
$about_19 = "Wyjazd o<br>określonej<br>godzinie";

$transport_1 = "Nasz transport";
$transport_2 = "Wszystko";
$transport_3 = "Auto";
$transport_4 = "Wnętrze";

$why_1 = "Dlaczego warto skorzystać<br>z naszych usług?";
$why_2 = "Nasza firma zajmuje się przewozem osób po Ukrainie, do Polski oraz w kierunku przeciwnym. Do tego używamy tylko wygodnych mikrobusów.";
$why_3 = "Cechą wyróżniającą naszą pracę jest nie tylko profesjonalizm i komfort dalekich podróży, ale także indywidualne podejście do każdego pasażera.";
$why_4 = "Uwzględniamy wszystkie życzenia i od razu zatrzymujemy się na żądanie każdego pasażera, zbierając pasażerów wzdłuż czerwonej linii miasta.";
$why_5 = "Możesz również skorzystać z naszych usług w zakresie dostarczania przesyłek. Z nami jest to łatwe, wygodne i co najważniejsze bezpieczne. Nasz transport jest zawsze sprawny technicznie. Przed każdą podróżą wszystko jest ściśle kontrolowane: samochody są sprawdzane, przeprowadzana jest regularna konserwacja. Kierowcy są zawsze przyjaźni i gościnni. Z nami masz pewność, że jesteś w dobrych rękach i że w wyznaczonym czasie będziesz we właściwym miejscu.";

$contacts_1 = "Kontaktu";
$contacts_2 = "Telefony:";
$contacts_3 = "Napisz do nas:";
$contacts_4 = "Zarezerwuj bilet autobusowy<br>Możesz zadzwonić za numerem <a href='tel:+380671237474' class='phone-link'><strong>+38 (067) 123 74 74</strong></a><br>lub przez naszą stronę internetową, wypełniając formularz:";
$contacts_5 = "Kierunek:";
$contacts_6 = "Twoje imię:";
$contacts_7 = "Twój numer telefonu:";
$contacts_8 = "Wiadomość:";
$contacts_9 = "Wysłać";

$popup_1 = "Prześlij nam swoje dane, a skontaktujemy się z tobą w ciągu kilku minut";
$popup_2 = "Kierunek:";
$popup_3 = "Twoje imię:";
$popup_4 = "Twój numer telefonu:";
$popup_5 = "Wysłać";
$popup_6 = "Poproś o oddzwonienie";

$endmodals_1 = "Trasa przebiega przez";
$endmodals_2 = "Trasa";
$endmodals_3 = "Zamknij";
$endmodals_4 = "Kup";