/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {
    /*----------Забронировать-------------------------------------------------*/
    $("#kr-lvov").click(function () {
        $('#direction').val("Кривой Рог - Львов");
    });
    
    $("#kr-kovel").click(function () {
        $('#direction').val("Кривой Рог - Ковель");
    });
    
    $("#kr-poznan").click(function () {
        $('#direction').val("Кривой Рог - Познань");
    });
    
    $("#kr-gdynya").click(function () {
        $('#direction').val("Кривой Рог - Гдыня");
    });
    
    $("#kr-gdansk").click(function () {
        $('#direction').val("Кривой Рог - Гданьск");
    });
    
    $("#kr-starograd-gdanskyy").click(function () {
        $('#direction').val("Кривой Рог - Старогард-Гданьский");
    });
    
    $("#kr-bydgosch").click(function () {
        $('#direction').val("Кривой Рог - Быдгощ");
    });
    
    $("#kr-lodz").click(function () {
        $('#direction').val("Кривой Рог - Лодзь");
    });
    
    $("#kr-varshava").click(function () {
        $('#direction').val("Кривой Рог - Варшава");
    });
    
    $("#kr-konin").click(function () {
        $('#direction').val("Кривой Рог - Конин");
    });
    
    $("#kr-kutno").click(function () {
        $('#direction').val("Кривой Рог - Кутно");
    });
    
    $("#kr-vrotslav").click(function () {
        $('#direction').val("Кривой Рог - Вроцлав");
    });
    
    $("#kr-opole").click(function () {
        $('#direction').val("Кривой Рог - Ополе");
    });
    
    $("#kr-krakov").click(function () {
        $('#direction').val("Кривой Рог - Краков");
    });
    
    $("#kr-katovice").click(function () {
        $('#direction').val("Кривой Рог - Катовице");
    });
    
    $("#kr-turek").click(function () {
        $('#direction').val("Кривой Рог - Турек");
    });
    
    $("#kr-torun").click(function () {
        $('#direction').val("Кривой Рог - Торунь");
    });
    
    $("#kr-glovno").click(function () {
        $('#direction').val("Кривой Рог - Гловно");
    });
    
    $("#kr-vzhesnya").click(function () {
        $('#direction').val("Кривой Рог - Вжесьня");
    });
    
    $("#kr-svazhends").click(function () {
        $('#direction').val("Кривой Рог - Сважендс");
    });
    
    $("#kr-grudzends").click(function () {
        $('#direction').val("Кривой Рог - Грудзёндс");
    });
    
    $("#kr-kvidzyn").click(function () {
        $('#direction').val("Кривой Рог - Квидзын");
    });
    
    $("#kr-tchev").click(function () {
        $('#direction').val("Кривой Рог - Тчев");
    });
    
    $("#kr-krakov").click(function () {
        $('#direction').val("Кривой Рог - Краков");
    });
    
    $("#kr-katovice").click(function () {
        $('#direction').val("Кривой Рог - Катовице");
    });
    
    $("#kr-mlava").click(function () {
        $('#direction').val("Кривой Рог - Млава");
    });
    
    $("#kr-olshtyn").click(function () {
        $('#direction').val("Кривой Рог - Ольштын");
    });
    
    $("#kr-ostruda").click(function () {
        $('#direction').val("Кривой Рог - Оструда");
    });
    
    $("#kr-elblong").click(function () {
        $('#direction').val("Кривой Рог - Эльблонг");
    });
    /*----------Украина-------------------------------------------------------*/
    $("#kr-lvov").click(function () {
        $('#direction').val("Кривой Рог - Львов");
    });
    $("#kr-nikolaev").click(function () {
        $('#direction').val("Кривой Рог - Николаев");
    });
    $("#kr-koblevo").click(function () {
        $('#direction').val("Кривой Рог - Коблево");
    });
    $("#kr-yuzhnyj").click(function () {
        $('#direction').val("Кривой Рог - Южный");
    });
    $("#kr-kotovskogo").click(function () {
        $('#direction').val("Кривой Рог - Одесса (поселок Котовского)");
    });
    $("#kr-ilichevsk").click(function () {
        $('#direction').val("Кривой Рог - Черноморское (Ильичевск)");
    });
    $("#kr-gribovka").click(function () {
        $('#direction').val("Кривой Рог - Грибовка");
    });
    $("#kr-karolina-bugaz").click(function () {
        $('#direction').val("Кривой Рог - Каролина-Бугаз");
    });
    $("#kr-zatoka").click(function () {
        $('#direction').val("Кривой Рог - Затока");
    });
    
    $("#kr-genichesk").click(function () {
        $('#direction').val("Кривой Рог - Геническ");
    });
    $("#kr-schaslivcevo").click(function () {
        $('#direction').val("Кривой Рог - Счастливцево");
    });
    $("#kr-strelkovoe").click(function () {
        $('#direction').val("Кривой Рог - Стрелковое");
    });
    $("#kr-skadovsk").click(function () {
        $('#direction').val("Кривой Рог - Скадовск");
    });
    $("#kr-lazurnoe").click(function () {
        $('#direction').val("Кривой Рог - Лазурное");
    });
    $("#kr-zheleznyj-port").click(function () {
        $('#direction').val("Кривой Рог - Железный Порт");
    });
    $("#kr-kirillovka").click(function () {
        $('#direction').val("Кривой Рог - Кирилловка");
    });
    $("#kr-berdyansk").click(function () {
        $('#direction').val("Кривой Рог - Бердянск");
    });
    /*----------Забронировать-------------------------------------------------*/
});